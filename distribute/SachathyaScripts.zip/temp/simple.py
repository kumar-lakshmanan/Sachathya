#For Sachathya
print('line1')
print('dsok')
print('kum')
print('dfd')

import sqlite3