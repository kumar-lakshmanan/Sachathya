'''
Created on Oct 9, 2017

@author: npn
'''


f = open('d:/sample.xml','r')
data = f.read()
print(data)
f.close()