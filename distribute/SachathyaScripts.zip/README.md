# SachathyaScripts
Sachathya Scripts are python scripts that are made to run in Sachathya framework.
