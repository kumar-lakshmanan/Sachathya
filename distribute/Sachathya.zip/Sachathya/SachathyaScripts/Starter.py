import sys

#for each in sys.path:
#    print(each)
    
def runMe(name):
    print('Helo '+name)
    
print('This is from Sachathya Script, Thanks for running me')