#For Sachathya

sch.schGUIObj.setWindowTitle("kumarsan and more")


sch.schUserGUI.addCustomTools('mydemo','books.png','./SachathyaScripts/myCommands/pathslash.py')


sch.schGUIObj.QuickTools.setVisible(0)



data = "This is file data"
sch.ttls.writeFileContent('ok.txt',data)
